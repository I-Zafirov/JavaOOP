package L03SayHello;

public interface Person {

    String getName();

    String sayHello();
}

