package L05BorderControl2;

public interface Identifiable {
    String getId();
}
