package L04SayHelloExtended;

public interface Person {

    String getName();

    String sayHello();
}
