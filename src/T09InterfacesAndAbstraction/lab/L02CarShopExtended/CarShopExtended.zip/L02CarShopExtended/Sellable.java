package L02CarShopExtended;

public interface Sellable {

    Double getPrice();

}
