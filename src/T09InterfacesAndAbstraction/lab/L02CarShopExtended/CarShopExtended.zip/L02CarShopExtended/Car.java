package L02CarShopExtended;

public interface Car {

    String getModel();

    String getColor();

    Integer getHorsePower();

    String countryProduced();

}
