package E04FoodShortage;

public interface Buyer {
    void buyFood();

    int getFood();
}
