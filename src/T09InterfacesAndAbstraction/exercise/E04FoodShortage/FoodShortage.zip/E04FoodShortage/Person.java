package E04FoodShortage;

public interface Person {
    String getName();

    int getAge();
}
