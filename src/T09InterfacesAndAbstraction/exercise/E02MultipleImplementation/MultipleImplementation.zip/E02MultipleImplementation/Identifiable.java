package E02MultipleImplementation;

public interface Identifiable {
    String getId();
}
