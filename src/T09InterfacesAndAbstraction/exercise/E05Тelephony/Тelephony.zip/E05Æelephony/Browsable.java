package E05Тelephony;

public interface Browsable {
    String browse();
}
