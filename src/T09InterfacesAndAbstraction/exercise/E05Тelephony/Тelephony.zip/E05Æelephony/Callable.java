package E05Тelephony;

public interface Callable {
    String call();
}
