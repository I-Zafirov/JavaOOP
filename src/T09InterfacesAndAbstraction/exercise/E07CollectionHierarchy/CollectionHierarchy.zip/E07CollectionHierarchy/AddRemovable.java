package E07CollectionHierarchy;

public interface AddRemovable extends Addable {
    String remove();
}
