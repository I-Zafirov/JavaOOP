package E06MilitaryElite.Enum;

public enum State {
    inProgress,
    finished;
}
