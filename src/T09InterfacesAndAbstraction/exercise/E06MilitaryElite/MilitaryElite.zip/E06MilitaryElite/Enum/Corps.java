package E06MilitaryElite.Enum;

public enum Corps {
    Airforces,
    Marines;
}
