package E06MilitaryElite.Interfaces;

import E06MilitaryElite.Repair;

import java.util.Collection;

public interface Engineer {
    Collection<Repair> getRepairs();
}
