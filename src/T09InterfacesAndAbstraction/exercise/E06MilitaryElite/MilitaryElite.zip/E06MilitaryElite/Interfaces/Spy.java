package E06MilitaryElite.Interfaces;

public interface Spy {
    String getCodeNumber();
}
