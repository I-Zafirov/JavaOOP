package E06MilitaryElite.Interfaces;

public interface Private extends Soldier {
    double getSalary();
}
