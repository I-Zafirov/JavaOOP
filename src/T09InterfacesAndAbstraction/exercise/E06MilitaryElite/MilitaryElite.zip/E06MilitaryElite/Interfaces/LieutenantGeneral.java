package E06MilitaryElite.Interfaces;

import java.util.List;

public interface LieutenantGeneral {
    List<Private> getCommandPrivateImpl();
}
