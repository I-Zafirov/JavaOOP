package E06MilitaryElite.Interfaces;

import E06MilitaryElite.Mission;

import java.util.Collection;

public interface Commando {
    Collection<Mission> getMissions();
}
