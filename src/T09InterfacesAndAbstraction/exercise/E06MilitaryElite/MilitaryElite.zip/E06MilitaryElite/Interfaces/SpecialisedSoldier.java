package E06MilitaryElite.Interfaces;

import E06MilitaryElite.Enum.Corps;

public interface SpecialisedSoldier {
    Corps getCorps();
}
