package telephony;

public interface Callable {

    String call();
}
