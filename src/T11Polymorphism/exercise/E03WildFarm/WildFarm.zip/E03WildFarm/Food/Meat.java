package E03WildFarm.Food;

public class Meat extends Food {

    public Meat(Integer quantity) {
        super(quantity);
    }
}
