package E01Vehicles;

public class Messages {
    public static final String TRAVELING = "%s travelled %s km";
    public static final String NOT_TRAVELING = "%s needs refueling";
}
