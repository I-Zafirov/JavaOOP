package E05Restaurant;

public class Main {
}
