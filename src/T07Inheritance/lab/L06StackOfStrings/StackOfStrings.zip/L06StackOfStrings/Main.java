package L06StackOfStrings;

public class Main {
    public static void main(String[] args) {

        StackOfStrings strings = new StackOfStrings();

        strings.push("my-solution");
        System.out.println(strings.peek());
    }
}
