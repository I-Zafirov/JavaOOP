package T03WorkingWithAbstraction.exercise.E01CardSuit;

public enum CardSuits {
    CLUBS, DIAMONDS, HEARTS, SPADES
}
