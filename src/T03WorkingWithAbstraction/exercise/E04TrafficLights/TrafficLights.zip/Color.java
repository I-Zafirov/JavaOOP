package T03WorkingWithAbstraction.exercise.E04TrafficLights;

public enum Color {
    RED,
    GREEN,
    YELLOW
}
